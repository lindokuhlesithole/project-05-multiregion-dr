import json
import boto3

def handler(event, context):
    print("Failover triggered")
    return {"statusCode": 200, "body": json.dumps("Failover executed")}
